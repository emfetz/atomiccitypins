/**
 * Aloha.Bsrowser
 *
 * The browser is an interface to interact with a Repository Managers
 */
define(["aloha","aloha/jquery","aloha/plugin","browser/browser"],function(e,t,n,r){return r});